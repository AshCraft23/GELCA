
  # Sistema de Gestión de Camarones

  This is a code bundle for Sistema de Gestión de Camarones.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
